AUTHOR='@xer0dayz'
VULN_NAME='CVE-2020-6287 - SAP NetWeaver AS JAVA LM Configuration Wizard Detection'
URI='/CTCWebService/CTCWebServiceBean/ConfigServlet'
METHOD='GET'
MATCH="CTCWebServiceSi"
SEVERITY='P5 - INFO'
CURL_OPTS="--user-agent '' -s -L --insecure -H 'Content-Type: text/xml; charset=UTF-8' "
SECONDARY_COMMANDS=''
GREP_OPTIONS='-i'