AUTHOR='@xer0dayz'
VULN_NAME='Joomla Detected 1'
URI='/joomla/'
METHOD='GET'
MATCH='content="Joomla! '
SEVERITY='P5 - INFO'
CURL_OPTS="--user-agent '' -s -L --insecure"
SECONDARY_COMMANDS=''
GREP_OPTIONS='-i'