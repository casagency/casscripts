AUTHOR='@xer0dayz'
VULN_NAME='Wordpress Detected 3'
URI='/wordpress/'
METHOD='GET'
MATCH="content\=\"WordPress"
SEVERITY='P5 - INFO'
CURL_OPTS="--user-agent '' -s -L --insecure"
SECONDARY_COMMANDS=''
GREP_OPTIONS='-i'